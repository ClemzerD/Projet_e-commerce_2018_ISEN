<?php include("include/head.php"); ?>

<body>
    <?php include("include/header.php"); ?>

	<section>
		<div class="text">
			<p>Inscription terminée, bienvenue sur le site de Rituel <?php echo $_GET['pseudo'];?> </p>
		</div>
	</section>
		
	<?php include("include/footer.php"); ?>
</body>