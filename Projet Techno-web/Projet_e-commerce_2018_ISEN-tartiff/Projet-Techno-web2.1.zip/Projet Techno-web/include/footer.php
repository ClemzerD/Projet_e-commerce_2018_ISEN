<footer>	
    <div>
        Copyright ISEN Lille - Tous droits réservés - Rituel Shop
   </div>
</footer>

</html>