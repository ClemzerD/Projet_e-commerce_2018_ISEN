<header><a id="headertitle" href="main.php">Rituel</a>

    <!--Sous Menu-->
    <nav>
         
        <div class="menuCategory">
    		<input type="text" name="recherche" id="recherche" placeholder="recherche">
			<input type="submit" value="Accepter">
    	</div>
            
        <div class="menuCategory">
			<a href="main.php">Menu</a>
    	</div>

    	<div class="menuCategory">
    		<a href="pagepanier.php">Panier</a>
		</div>

    	<div class="menuCategory">
    		<a href="pageconnexion.php">Connexion</a>
		</div>

    </nav>

</header>