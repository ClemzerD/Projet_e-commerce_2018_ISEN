<?php include("include/head.php"); ?>

<body>
	<!--Titre-->
    <?php include("include/header.php"); ?>

	<section>
		<div class="pres">
			<figure>
    			<a href="pagesweat.php"><img id="photopres" src="image/sweat.jpg" alt="sweat" />
    			<figcaption>SWEAT</figcaption></a>
    		</figure>
    		<figure>
    			<a href="pagepull.php"><img id="photopres" src="image/pull.jpg" alt="pull" />
   				<figcaption>PULL</figcaption></a>
   			</figure>
   			<figure>
    			<a href="pagetshirt.php"><img id="photopres" src="image/tshirt.jpg" alt="tshirt" />
    			<figcaption>T-SHIRT</figcaption></a>
   			</figure>
		</div>
	</section>

	<?php include("include/footer.php"); ?>
</body>
</html>