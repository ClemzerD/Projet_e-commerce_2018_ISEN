<?php include("include/head.php"); ?>

<body>
    <?php include("include/header.php"); ?>

	<section>
		

	</section>
		
	<?php include("include/footer.php"); ?>
</body>